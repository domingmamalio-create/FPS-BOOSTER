# FPS Booster Pro — MT Manager Edition

A mobile-style FPS boost & resolution stretch app.

## Features
- Real-time FPS graph display
- Screen resolution & stretch control
- FPS unlock (60 / 90 / 120 / 144 / 165 / 240)
- DPI override
- Aspect ratio selector (18:9 to 21:9)
- Game profiles (PUBG, Free Fire, ML, CoD)
- MT Manager APK patch simulator
- Draggable floating panel overlay
- Animated particle background

## Structure
fps-booster/
├── index.html
├── README.md
├── css/
│   ├── style.css
│   ├── panel.css
│   └── animations.css
├── js/
│   ├── app.js
│   ├── panel.js
│   ├── graph.js
│   ├── games.js
│   ├── patch.js
│   └── bg.js
├── config/
│   ├── profiles.json
│   └── mt_patch_rules.json
└── assets/

## Usage
Open index.html in any browser.
On Android — use via WebView or any browser.

## Float Panel
Enable the floating panel from the app — then it stays
on top of your game screen like an overlay.
Drag it anywhere. Tap ⚡ to boost, ⛶ to stretch, ✕ to close.
