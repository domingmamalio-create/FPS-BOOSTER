/* ===== GAME PROFILES ===== */
var GAMES = [
  { icon:'🎮', name:'PUBG Mobile', sub:'90 FPS · Smooth · Anti-Lag', fps:90, badge:'ACTIVE', cls:'' },
  { icon:'🔫', name:'Free Fire MAX', sub:'120 FPS · Ultra · Stretch 19:9', fps:120, badge:'120 FPS', cls:'orange' },
  { icon:'⚔️', name:'Mobile Legends', sub:'60 FPS · High · Default', fps:60, badge:'READY', cls:'' },
  { icon:'🏎️', name:'Call of Duty Mobile', sub:'60 FPS · Medium · Balanced', fps:60, badge:'READY', cls:'' },
  { icon:'🎯', name:'Valorant Mobile', sub:'90 FPS · High · Unlocked', fps:90, badge:'ACTIVE', cls:'' },
];

function renderGames() {
  var list = document.getElementById('game-list');
  list.innerHTML = '';
  GAMES.forEach(function(g, i) {
    var div = document.createElement('div');
    div.className = 'game-item' + (i === 0 ? ' selected' : '');
    div.innerHTML =
      '<div class="game-icon">' + g.icon + '</div>' +
      '<div class="game-info">' +
        '<div class="game-name">' + g.name + '</div>' +
        '<div class="game-sub">' + g.sub + '</div>' +
      '</div>' +
      '<div class="game-badge ' + g.cls + '">' + g.badge + '</div>';
    div.addEventListener('click', function() {
      document.querySelectorAll('.game-item').forEach(function(el){ el.classList.remove('selected'); });
      div.classList.add('selected');
      window.targetFPS = g.fps;
      toast('Profile: ' + g.name + ' (' + g.fps + ' FPS)');
    });
    list.appendChild(div);
  });
}

document.addEventListener('DOMContentLoaded', renderGames);
setTimeout(renderGames, 0);
