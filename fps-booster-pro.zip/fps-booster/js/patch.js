/* ===== MT MANAGER PATCH ENGINE ===== */
var FAKE_APKS = ['com.tencent.ig','com.garena.game.freefire','com.mobile.legends','com.activision.callofduty.shooter'];
var selectedAPK = null;

function pickAPK() {
  var apk = FAKE_APKS[Math.floor(Math.random() * FAKE_APKS.length)];
  var ver = (Math.floor(Math.random()*10)+1) + '.' + Math.floor(Math.random()*9);
  selectedAPK = apk;
  document.getElementById('apk-info').innerHTML =
    '<b style="color:var(--accent)">' + apk + '</b><br>' +
    '<span style="color:var(--muted)">v' + ver + ' · ' + (Math.floor(Math.random()*60+40)) + ' MB · arm64-v8a</span>';
  toast('APK Selected: ' + apk.split('.').pop());
}

var PATCH_STEPS = [
  'Decompiling APK...',
  'Parsing smali files...',
  'Locating render config...',
  'Injecting FPS patch...',
  'Rebuilding resources...',
  'Re-signing APK...',
  'Verifying integrity...',
  'Patch complete!',
];

function startPatch() {
  if (!selectedAPK) { toast('Select an APK first!', 'var(--red)'); return; }
  var mode = document.getElementById('patch-mode').value;
  var pw = document.getElementById('patch-progress');
  var fill = document.getElementById('p-fill');
  var label = document.getElementById('p-label');
  pw.style.display = 'block';
  var step = 0;
  setStatus('boosting', 'PATCHING');
  function nextStep() {
    if (step >= PATCH_STEPS.length) {
      setStatus('active', 'ACTIVE');
      toast('Patch Done: ' + mode);
      return;
    }
    label.textContent = PATCH_STEPS[step];
    fill.style.width = ((step + 1) / PATCH_STEPS.length * 100) + '%';
    step++;
    setTimeout(nextStep, 400 + Math.random() * 300);
  }
  nextStep();
}
