/* ===== DRAGGABLE FLOAT PANEL ===== */
(function(){
  var panel = document.getElementById('float-panel');
  var handle = document.getElementById('fp-handle');
  var dragging = false;
  var ox = 0, oy = 0, px = 0, py = 0;

  function getPos(e) {
    if (e.touches) return { x: e.touches[0].clientX, y: e.touches[0].clientY };
    return { x: e.clientX, y: e.clientY };
  }

  function onStart(e) {
    dragging = true;
    var pos = getPos(e);
    var rect = panel.getBoundingClientRect();
    ox = pos.x - rect.left;
    oy = pos.y - rect.top;
    panel.style.transition = 'none';
    e.preventDefault();
  }

  function onMove(e) {
    if (!dragging) return;
    var pos = getPos(e);
    var x = pos.x - ox;
    var y = pos.y - oy;
    var maxX = window.innerWidth - panel.offsetWidth - 4;
    var maxY = window.innerHeight - panel.offsetHeight - 4;
    x = Math.max(4, Math.min(x, maxX));
    y = Math.max(4, Math.min(y, maxY));
    panel.style.left = x + 'px';
    panel.style.top = y + 'px';
    panel.style.right = 'auto';
    e.preventDefault();
  }

  function onEnd() { dragging = false; }

  handle.addEventListener('mousedown', onStart);
  handle.addEventListener('touchstart', onStart, { passive: false });
  document.addEventListener('mousemove', onMove);
  document.addEventListener('touchmove', onMove, { passive: false });
  document.addEventListener('mouseup', onEnd);
  document.addEventListener('touchend', onEnd);
})();
