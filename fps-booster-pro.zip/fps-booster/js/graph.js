/* ===== FPS GRAPH ===== */
(function(){
  var canvas = document.getElementById('fps-graph');
  var ctx = canvas.getContext('2d');
  var history = [];
  var maxLen = 40;
  var targetFPSRef = 90;

  function randFPS(base) {
    var jitter = (Math.random() - 0.5) * 8;
    return Math.max(30, Math.min(base + jitter, base + 4));
  }

  function draw() {
    var w = canvas.offsetWidth || 200;
    var h = canvas.offsetHeight || 48;
    canvas.width = w;
    canvas.height = h;
    ctx.clearRect(0, 0, w, h);

    if (history.length < 2) return;
    var minV = 20, maxV = 260;
    var step = w / (maxLen - 1);

    ctx.beginPath();
    ctx.moveTo(0, h - ((history[0] - minV) / (maxV - minV)) * h);
    for (var i = 1; i < history.length; i++) {
      var x = i * step;
      var y = h - ((history[i] - minV) / (maxV - minV)) * h;
      ctx.lineTo(x, y);
    }

    var grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, 'rgba(0,255,136,.8)');
    grad.addColorStop(1, 'rgba(0,255,136,.05)');
    ctx.strokeStyle = '#00ff88';
    ctx.lineWidth = 2;
    ctx.shadowColor = '#00ff88';
    ctx.shadowBlur = 4;
    ctx.stroke();
  }

  function tick() {
    var tgt = window.targetFPS || 90;
    var fp = (window.boosting) ? randFPS(tgt) : randFPS(currentFPS || tgt);
    history.push(fp);
    if (history.length > maxLen) history.shift();
    updateFPSDisplay(fp);
    var tempEl = document.getElementById('temp-num');
    if (tempEl) tempEl.textContent = (35 + Math.floor(Math.random()*6)) + '°';
    draw();
    requestAnimationFrame(function(){ setTimeout(tick, 250); });
  }

  tick();
})();
