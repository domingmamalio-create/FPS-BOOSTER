/* ===== GLOBALS ===== */
var currentFPS = 90;
var targetFPS = 90;
var boosting = false;
var fpsHistory = [];
var toastTimer = null;

/* ===== TOAST ===== */
function toast(msg, color) {
  var t = document.getElementById('toast-el');
  if (!t) { t = document.createElement('div'); t.id='toast-el'; t.className='toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.style.borderColor = color || 'var(--accent)';
  t.style.color = color || 'var(--accent)';
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ t.classList.remove('show'); }, 2200);
}

/* ===== STATUS ===== */
function setStatus(state, label) {
  var dot = document.getElementById('status-dot');
  var txt = document.getElementById('status-txt');
  dot.className = 'status-dot ' + state;
  txt.textContent = label;
}

/* ===== QUICK ACTIONS ===== */
function quickAction(type) {
  var btn = document.getElementById('qb-' + type);
  btn.classList.add('active');
  setTimeout(function(){ btn.classList.remove('active'); }, 600);
  if (type === 'boost') {
    runBoost();
  } else if (type === 'stretch') {
    toast('Screen Stretch Applied!');
  } else if (type === 'unlock') {
    applyFPS();
  } else if (type === 'clear') {
    clearRAM();
  }
}

function runBoost() {
  if (boosting) return;
  boosting = true;
  setStatus('boosting', 'BOOSTING');
  toast('Boosting FPS...', 'var(--orange)');
  var step = 0;
  var interval = setInterval(function() {
    step++;
    var boost = Math.min(targetFPS, currentFPS + step * 3);
    updateFPSDisplay(boost);
    if (step >= 20) {
      clearInterval(interval);
      boosting = false;
      currentFPS = targetFPS;
      setStatus('active', 'ACTIVE');
      toast('Boost Complete! ' + targetFPS + ' FPS', 'var(--accent)');
    }
  }, 60);
}

function clearRAM() {
  setStatus('boosting', 'CLEARING');
  toast('Clearing RAM...', 'var(--orange)');
  setTimeout(function(){
    setStatus('active', 'ACTIVE');
    toast('RAM Cleared! +' + Math.floor(Math.random()*400+200) + 'MB freed');
  }, 1800);
}

/* ===== FPS DISPLAY ===== */
function updateFPSDisplay(val) {
  var el = document.getElementById('fps-num');
  if (el) el.textContent = Math.round(val);
  var fp = document.getElementById('fp-fps-num');
  if (fp) fp.textContent = Math.round(val);
}

/* ===== ASPECT RATIO ===== */
function setAspect(btn, val) {
  document.querySelectorAll('#aspect-group .tog').forEach(function(b){ b.classList.remove('active'); });
  btn.classList.add('active');
  toast('Aspect ratio: ' + val);
}

/* ===== RESOLUTION ===== */
function updateRes() {
  var sel = document.getElementById('res-select');
  var row = document.getElementById('custom-res-row');
  row.style.display = sel.value === 'custom' ? 'flex' : 'none';
}

function applyResolution() {
  var sel = document.getElementById('res-select');
  var res = sel.value === 'custom'
    ? (document.getElementById('cw').value || '?') + 'x' + (document.getElementById('ch').value || '?')
    : sel.value;
  setStatus('boosting', 'APPLYING');
  setTimeout(function(){
    setStatus('active', 'ACTIVE');
    toast('Resolution set: ' + res);
  }, 1200);
}

/* ===== DPI ===== */
function updateDPI(val) {
  document.getElementById('dpi-val').textContent = val + ' dpi';
}

/* ===== STRETCH ===== */
function updateStretch(val) {
  document.getElementById('stretch-val').textContent = val + '%';
}

/* ===== FPS UNLOCK ===== */
function setFPS(btn, val) {
  document.querySelectorAll('.toggle-group .tog').forEach(function(b){ /* only in parent */ });
  btn.parentNode.querySelectorAll('.tog').forEach(function(b){ b.classList.remove('active'); });
  btn.classList.add('active');
  targetFPS = val;
  toast('Target FPS set: ' + val);
}

function applyFPS() {
  setStatus('boosting', 'UNLOCKING');
  toast('Unlocking ' + targetFPS + ' FPS...', 'var(--accent2)');
  setTimeout(function(){
    currentFPS = targetFPS;
    updateFPSDisplay(targetFPS);
    setStatus('active', 'ACTIVE');
    toast(targetFPS + ' FPS Unlocked!');
  }, 1500);
}

/* ===== SWITCH HELPERS ===== */
function toggleSw(swId, lblId) {
  var checked = document.getElementById(swId).checked;
  document.getElementById(lblId).textContent = checked ? 'ON' : 'OFF';
}

document.getElementById('sync-sw').addEventListener('change', function(){
  document.getElementById('sync-lbl').textContent = this.checked ? 'ON' : 'OFF';
});

/* ===== FLOAT PANEL ===== */
function updateOpacity(val) {
  document.getElementById('opacity-val').textContent = val + '%';
  var fp = document.getElementById('float-panel');
  fp.style.opacity = val / 100;
}

function toggleFloat() {
  var sw = document.getElementById('float-sw');
  var lbl = document.getElementById('float-lbl');
  var fp = document.getElementById('float-panel');
  if (sw.checked) {
    lbl.textContent = 'ON';
    fp.style.display = 'block';
    fp.classList.add('anim-slide');
    toast('Floating panel enabled');
  } else {
    lbl.textContent = 'OFF';
    fp.style.display = 'none';
    toast('Floating panel disabled');
  }
}

function hideFloat() {
  document.getElementById('float-panel').style.display = 'none';
  document.getElementById('float-sw').checked = false;
  document.getElementById('float-lbl').textContent = 'OFF';
}

function setPanelSize(btn, sz) {
  btn.parentNode.querySelectorAll('.tog').forEach(function(b){ b.classList.remove('active'); });
  btn.classList.add('active');
  var fp = document.getElementById('float-panel');
  if (sz === 'sm') fp.style.minWidth = '60px';
  else if (sz === 'md') fp.style.minWidth = '80px';
  else fp.style.minWidth = '110px';
  toast('Panel size: ' + sz.toUpperCase());
}

/* ===== QUICK FPS FLOAT ACTIONS ===== */
function fpBoost() { runBoost(); toast('Boost!', 'var(--orange)'); }
function fpStretch() { toast('Stretch toggled!'); }
